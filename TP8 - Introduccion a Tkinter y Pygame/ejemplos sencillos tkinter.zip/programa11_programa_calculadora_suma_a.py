# -*- coding: utf-8 -*-
"""
Programa calculadora simple
"""
import tkinter as tk

# Creación de la ventana principal
root = tk.Tk()  
root.title("Sumar dos números")

# Casilla de texto para el primer número 
numero1 = tk.Entry(root)
numero1.grid(row=0, column=0) 

# Casilla de texto para el segundo número
numero2 = tk.Entry(root)  
numero2.grid(row=1, column=0)

# Etiqueta para mostrar el resultado
resultado = tk.Label(root, text="")
resultado.grid(row=2, column=0) 

# Función para sumar los dos números   
def sumar():
    n1 = float(numero1.get())
    n2 = float(numero2.get())
    r = n1 + n2
    
    resultado.config(text=f"Resultado: {r}")

# Botón para activar la suma         
boton = tk.Button(root, text="Sumar", command=sumar)
boton.grid(row=3, column=0) 

# Bucle principal
root.mainloop()