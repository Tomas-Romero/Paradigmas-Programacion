import tkinter as tk
def calcular():
    try:
        num1 = float(entrada_num1.get())
        num2 = float(entrada_num2.get())

        if operacion.get() == "Suma":
            resultado = num1 + num2
        elif operacion.get() == "Resta":
            resultado = num1 - num2
        else:
            resultado = "Operación no válida"

        resultado_str.set(resultado)
    except ValueError:
        resultado_str.set("Error: Ingresa números válidos")

def salir():
    root.destroy()

root = tk.Tk()
root.title("Calculadora Simple")

# Etiquetas
etiqueta_num1 = tk.Label(root, text="Número 1:")
etiqueta_num1.grid(row=0, column=0, padx=5, pady=5)

etiqueta_num2 = tk.Label(root, text="Número 2:")
etiqueta_num2.grid(row=1, column=0, padx=5, pady=5)

etiqueta_operacion = tk.Label(root, text="Operación:")
etiqueta_operacion.grid(row=2, column=0, padx=5, pady=5)

etiqueta_resultado = tk.Label(root, text="Resultado:")
etiqueta_resultado.grid(row=3, column=0, padx=5, pady=5)

# Cajas de Texto
entrada_num1 = tk.Entry(root)
entrada_num1.grid(row=0, column=1, padx=5, pady=5)

entrada_num2 = tk.Entry(root)
entrada_num2.grid(row=1, column=1, padx=5, pady=5)

resultado_str = tk.StringVar()
resultado_str.set("0")
entrada_resultado = tk.Entry(root, textvariable=resultado_str, state="readonly")
entrada_resultado.grid(row=3, column=1, padx=5, pady=5)

# Radiobuttons
operacion = tk.StringVar()
operacion.set("Suma")

radiobtn_suma = tk.Radiobutton(root, text="Suma", variable=operacion, value="Suma")
radiobtn_suma.grid(row=2, column=1, padx=5, pady=5)

radiobtn_resta = tk.Radiobutton(root, text="Resta", variable=operacion, value="Resta")
radiobtn_resta.grid(row=2, column=2, padx=5, pady=5)

# Botones
boton_calcular = tk.Button(root, text="Calcular", command=calcular)
boton_calcular.grid(row=4, column=0, columnspan=2, padx=5, pady=10)

boton_salir = tk.Button(root, text="Salir", command=salir)
boton_salir.grid(row=5, column=0, columnspan=2, padx=5, pady=5)

root.mainloop()

