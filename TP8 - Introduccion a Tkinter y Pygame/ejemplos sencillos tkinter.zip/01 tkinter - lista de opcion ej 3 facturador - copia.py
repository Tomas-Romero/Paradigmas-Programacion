# -*- coding: utf-8 -*-
"""
Created on Fri Jul 28 15:22:22 2023

@author: Usuario
"""
import tkinter as tk
def calcular_factura():
    try:
        alquiler = float(entrada_alquiler.get())
        total = alquiler
        if opcion_pileta.get():
            total += 20
        if opcion_aire_acond.get():
            total += 30
        if opcion_cochera.get():
            total += 25
        etiqueta_resultado.config(text=f"Total a pagar: ${total:.2f}")
    except ValueError:
        etiqueta_resultado.config(text="Error: Ingrese un valor válido")
root = tk.Tk()
root.title("Facturador")
etiqueta_alquiler = tk.Label(root, text="Ingrese el valor del alquiler:")
etiqueta_alquiler.pack(pady=10)
entrada_alquiler = tk.Entry(root, width=10)
entrada_alquiler.pack(pady=5)
opcion_pileta = tk.BooleanVar() #crea una variable especial de tipo BooleanVar en Tkinter. Esta variable se utiliza para almacenar el estado de una casilla de verificación (checkbox) 
opcion_aire_acond = tk.BooleanVar()
opcion_cochera = tk.BooleanVar()
checklist = tk.Checkbutton(root, text="Pileta $20", variable=opcion_pileta) ##crea un widget de casilla de verificación (checkbutton) en Tkinter
checklist.pack(anchor=tk.W)
checklist = tk.Checkbutton(root, text="Aire Acond $30", variable=opcion_aire_acond)
checklist.pack(anchor=tk.W)
checklist = tk.Checkbutton(root, text="Cochera $25", variable=opcion_cochera)
checklist.pack(anchor=tk.W)
boton_calcular = tk.Button(root, text="Calcular", command=calcular_factura)
boton_calcular.pack(pady=10)
etiqueta_resultado = tk.Label(root, text="")
etiqueta_resultado.pack(pady=10)
root.mainloop()
