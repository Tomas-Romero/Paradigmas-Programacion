# -*- coding: utf-8 -*-
"""
Created on Mon Aug 21 21:54:48 2023

@author: Usuario
"""

import tkinter as tk

# Esta es la ventana principal de la aplicación.
window = tk.Tk()
window.title("Liquidador de sueldos")

# Este es el marco que contiene los campos de entrada.
input_frame = tk.Frame(window)

# Esta es la etiqueta para el campo de sueldo bruto.
sueldo_bruto_label = tk.Label(input_frame, text="Sueldo bruto:")
sueldo_bruto_label.pack()

# Este es el campo de entrada para el sueldo bruto.
sueldo_bruto_entry = tk.Entry(input_frame)
sueldo_bruto_entry.pack()

# Esta es la etiqueta para el campo de horas extra.
horas_extra_label = tk.Label(input_frame, text="Horas extra:")
horas_extra_label.pack()

# Este es el campo de entrada para las horas extra.
horas_extra_entry = tk.Entry(input_frame)
horas_extra_entry.pack()

# Esta es la etiqueta para el campo de premio de la empresa.
premio_empresa_label = tk.Label(input_frame, text="Premio de la empresa:")
premio_empresa_label.pack()

# Este es el campo de entrada para el premio de la empresa.
premio_empresa_entry = tk.Entry(input_frame)
premio_empresa_entry.pack()

# Esta es la etiqueta para el campo de presentismo.
presentismo_label = tk.Label(input_frame, text="Presentismo:")
presentismo_label.pack()

# Este es el campo de entrada para el presentismo.
presentismo_entry = tk.Entry(input_frame)
presentismo_entry.pack()

# Esta es la etiqueta para el campo de zona.
zona_label = tk.Label(input_frame, text="Zona:")
zona_label.pack()

# Este es el campo de entrada para la zona.
zona_entry = tk.Entry(input_frame)
zona_entry.pack()

# Esta es la etiqueta para el campo de item por trabajo riesgoso.
item_trabajo_riesgoso_label = tk.Label(input_frame, text="Item por trabajo riesgoso:")
item_trabajo_riesgoso_label.pack()

# Este es el campo de entrada para el item por trabajo riesgoso.
item_trabajo_riesgoso_entry = tk.Entry(input_frame)
item_trabajo_riesgoso_entry.pack()

input_frame.pack()

# Este es el marco que contiene los campos de salida.
output_frame = tk.Frame(window)

# Esta es la etiqueta para el campo de sueldo neto.
sueldo_neto_label = tk.Label(output_frame, text="Sueldo neto:")
sueldo_neto_label.pack()

# Este es el campo de salida para el sueldo neto.
sueldo_neto_output = tk.Label(output_frame, text="")
sueldo_neto_output.pack()

# Estas son las etiquetas y campos de salida para las deducciones
jubilacion_label = tk.Label(output_frame, text="Jubilación 11%:")
jubilacion_label.pack()
jubilacion_output = tk.Label(output_frame, text="")
jubilacion_output.pack()

ley_19032_label = tk.Label(output_frame, text="Ley 19032 3%:")
ley_19032_label.pack()
ley_19032_output = tk.Label(output_frame, text="")
ley_19032_output.pack()

obra_social_label = tk.Label(output_frame, text="Obra social 3%:")
obra_social_label.pack()
obra_social_output = tk.Label(output_frame, text="")
obra_social_output.pack()

sindicato_label = tk.Label(output_frame, text="Sindicato 2%:")
sindicato_label.pack()
sindicato_output = tk.Label(output_frame, text="")
sindicato_output.pack()

output_frame.pack()

# Este es el botón que calcula el sueldo neto.
calcular_button = tk.Button(window, text="Calcular")
calcular_button.pack()

def calcular_sueldo_neto():
    # Obtener los valores de entrada.
    sueldo_bruto = float(sueldo_bruto_entry.get())
    horas_extra = float(horas_extra_entry.get())
    premio_empresa = float(premio_empresa_entry.get())
    presentismo = float(presentismo_entry.get())
    zona = float(zona_entry.get())
    item_trabajo_riesgoso = float(item_trabajo_riesgoso_entry.get())

    # Calcular deducciones
    jubilacion_calculada = sueldo_bruto * 0.11
    ley_19032_calculada = sueldo_bruto * 0.03
    obra_social_calculada = sueldo_bruto * 0.03
    sindicato_calculado = sueldo_bruto * 0.02
    total_deducciones = jubilacion_calculada + ley_19032_calculada + obra_social_calculada + sindicato_calculado

    # Calcular haberes
    presentismo_calculado = sueldo_bruto * 0.03
    zona_calculada = sueldo_bruto * 0.02
    total_earnings = horas_extra + premio_empresa + presentismo_calculado + zona_calculada + item_trabajo_riesgoso

    # Calcular sueldo neto
    sueldo_neto = sueldo_bruto + total_earnings - total_deducciones

    # Establecer valores de salida
    sueldo_neto_output.config(text=str(sueldo_neto))
    jubilacion_output.config(text=str(jubilacion_calculada))
    ley_19032_output.config(text=str(ley_19032_calculada))
    obra_social_output.config(text=str(obra_social_calculada))
    sindicato_output.config(text=str(sindicato_calculado))

calcular_button.config(command=calcular_sueldo_neto)

window.mainloop()
