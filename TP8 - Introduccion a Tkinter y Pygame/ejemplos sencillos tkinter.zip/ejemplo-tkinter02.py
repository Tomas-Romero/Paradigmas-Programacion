import tkinter as tk
from tkinter import ttk

# Clase principal de la calculadora de conversión
class ConversionCalculator:
    def __init__(self, root):
        self.root = root
        self.root.title("Calculadora de Conversión de Longitud")
        
        # Unidades de longitud
        self.units = ["km", "hm", "dam", "m", "dm", "cm", "mm"]
        
        # Crear widgets
        self.create_widgets()
    
    def create_widgets(self):
        # Etiqueta y entrada para el valor a convertir
        self.value_label = tk.Label(self.root, text="Valor:")
        self.value_label.grid(row=0, column=0, padx=10, pady=10)
        
        self.value_entry = tk.Entry(self.root)
        self.value_entry.grid(row=0, column=1, padx=10, pady=10)
        
        # Combobox para seleccionar la unidad de origen
        self.from_unit_label = tk.Label(self.root, text="De:")
        self.from_unit_label.grid(row=1, column=0, padx=10, pady=10)
        
        self.from_unit_combobox = ttk.Combobox(self.root, values=self.units)
        self.from_unit_combobox.grid(row=1, column=1, padx=10, pady=10)
        
        # Combobox para seleccionar la unidad de destino
        self.to_unit_label = tk.Label(self.root, text="A:")
        self.to_unit_label.grid(row=2, column=0, padx=10, pady=10)
        
        self.to_unit_combobox = ttk.Combobox(self.root, values=self.units)
        self.to_unit_combobox.grid(row=2, column=1, padx=10, pady=10)
        
        # Botón para realizar la conversión
        self.convert_button = tk.Button(self.root, text="Convertir", command=self.convert)
        self.convert_button.grid(row=3, column=0, columnspan=2, padx=10, pady=10)
        
        # Etiqueta para mostrar el resultado
        self.result_label = tk.Label(self.root, text="Resultado:")
        self.result_label.grid(row=4, column=0, padx=10, pady=10)
        
        self.result_value_label = tk.Label(self.root, text="")
        self.result_value_label.grid(row=4, column=1, padx=10, pady=10)
    
    def convert(self):
        try:
            # Obtener el valor y las unidades seleccionadas
            value = float(self.value_entry.get())
            from_unit = self.from_unit_combobox.get()
            to_unit = self.to_unit_combobox.get()
            
            # Diccionario con los factores de conversión al metro
            conversion_factors = {
                "km": 1000,
                "hm": 100,
                "dam": 10,
                "m": 1,
                "dm": 0.1,
                "cm": 0.01,
                "mm": 0.001
            }
            
            # Convertir el valor a metros
            value_in_meters = value * conversion_factors[from_unit]
            
            # Convertir el valor de metros a la unidad de destino
            result = value_in_meters / conversion_factors[to_unit]
            
            # Mostrar el resultado
            self.result_value_label.config(text=f"{result:.4f} {to_unit}")
        except ValueError:
            self.result_value_label.config(text="Entrada no válida")
        except KeyError:
            self.result_value_label.config(text="Unidad no válida")

# Crear la ventana principal de Tkinter
root = tk.Tk()
app = ConversionCalculator(root)
root.mainloop()
