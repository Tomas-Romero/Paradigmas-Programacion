# -*- coding: utf-8 -*-
"""
Created on Fri Jul 28 17:01:24 2023

@author: Usuario
"""

import tkinter as tk
from tkinter import messagebox

def calcular():
    try:
        valor1 = float(entrada_valor1.get())
        valor2 = float(entrada_valor2.get())
        figura = lista_figuras.get()
        resultado = 0

        if figura == "Rectángulo":
            if opcion_perimetro.get() == 1:
                resultado = 2 * (valor1 + valor2)
            else:
                resultado = valor1 * valor2
        elif figura == "Triángulo":
            if opcion_perimetro.get() == 1:
                resultado = 3 * valor1
            else:
                resultado = (valor1 * valor2) / 2
 

        if opcion_unidades.get():
            resultado = resultado*100
            resultado_str.set(f"{resultado} cm")
            
        else:
            resultado = resultado
            resultado_str.set(f"{resultado} m")
            

    except ValueError:
        messagebox.showerror("Error", "Por favor, ingresa valores numéricos válidos.")

def acerar_valores():
    entrada_valor1.delete(0, tk.END)
    entrada_valor2.delete(0, tk.END)
    resultado_str.set("")

def salir():
    root.destroy()

root = tk.Tk()
root.title("Calculadora de Perímetro y Superficie")

# Funcionalidad para Radiobutton
opcion_perimetro = tk.IntVar()
opcion_perimetro.set(1)  # Valor inicial para el cálculo del perímetro

# Funcionalidad para Checklist
opcion_unidades = tk.BooleanVar()
opcion_unidades.set(True)  # Valor inicial para mostrar el resultado en centímetros

# Etiquetas
etiqueta_valor1 = tk.Label(root, text="Valor 1:")
etiqueta_valor1.grid(row=0, column=0, padx=5, pady=5)

etiqueta_valor2 = tk.Label(root, text="Valor 2:")
etiqueta_valor2.grid(row=1, column=0, padx=5, pady=5)

##etiqueta_valor3 = tk.Label(root, text="Base Menor (Trapecio):")
##etiqueta_valor3.grid(row=2, column=0, padx=5, pady=5)

etiqueta_figura = tk.Label(root, text="Selecciona la Figura:")
etiqueta_figura.grid(row=3, column=0, padx=5, pady=5)

etiqueta_resultado = tk.Label(root, text="Resultado:")
etiqueta_resultado.grid(row=6, column=0, padx=5, pady=5)

# Cajas de Texto
entrada_valor1 = tk.Entry(root)
entrada_valor1.grid(row=0, column=1, padx=5, pady=5)

entrada_valor2 = tk.Entry(root)
entrada_valor2.grid(row=1, column=1, padx=5, pady=5)

##entrada_valor3 = tk.Entry(root)
##entrada_valor3.grid(row=2, column=1, padx=5, pady=5)

resultado_str = tk.StringVar()
resultado_str.set("")
entrada_resultado = tk.Entry(root, textvariable=resultado_str, state="readonly")
entrada_resultado.grid(row=6, column=1, padx=5, pady=5)

# Lista de opciones
lista_figuras = tk.StringVar()
lista_figuras.set("Rectángulo")
menu_figuras = tk.OptionMenu(root, lista_figuras, "Rectángulo", "Triángulo")
menu_figuras.grid(row=3, column=1, padx=5, pady=5)

# Radiobuttons
radiobtn_perimetro = tk.Radiobutton(root, text="Perímetro", variable=opcion_perimetro, value=1)
radiobtn_perimetro.grid(row=4, column=0, padx=5, pady=5)

radiobtn_superficie = tk.Radiobutton(root, text="Superficie", variable=opcion_perimetro, value=2)
radiobtn_superficie.grid(row=4, column=1, padx=5, pady=5)

# Checklist
check_unidades = tk.Checkbutton(root, text="Mostrar resultado en centímetros", variable=opcion_unidades)
check_unidades.grid(row=5, column=0, columnspan=2, padx=5, pady=5)

# Botones
boton_calcular = tk.Button(root, text="Calcular", command=calcular)
boton_calcular.grid(row=7, column=0, columnspan=2, padx=5, pady=10)

boton_acerar = tk.Button(root, text="Acerar Valores", command=acerar_valores)
boton_acerar.grid(row=8, column=0, columnspan=2, padx=5, pady=5)

boton_salir = tk.Button(root, text="Salir", command=salir)
boton_salir.grid(row=9, column=0, columnspan=2, padx=5, pady=5)

root.mainloop()
