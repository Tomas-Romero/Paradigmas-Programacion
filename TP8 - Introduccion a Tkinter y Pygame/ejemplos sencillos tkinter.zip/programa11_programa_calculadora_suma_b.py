# -*- coding: utf-8 -*-
"""
Created on Mon Aug 21 20:55:08 2023

@author: Usuario
"""

import tkinter as tk

# Ventana principal 
root = tk.Tk()
root.title("Sumar dos números")

# Entry número 1  
numero1 = tk.Entry(root)
numero1.grid(row=0, column=0)

# Entry número 2
numero2 = tk.Entry(root) 
numero2.grid(row=1, column=0)

# Entry resultado en modo solo lectura 
resultado = tk.Entry(root)
resultado.grid(row=2, column=0)
resultado.config(state="readonly") 

# Función para sumar
def sumar():
    n1 = float(numero1.get())
    n2 = float(numero2.get())
    r = n1 + n2
    
    resultado.config(state="normal") ## cambia a atributo normal para modificar
    resultado.delete(0, tk.END) ##Borra el contenido actual de la caja de texto, desde la posicion 0 hasta el final (tk.END).
    resultado.insert(0, r) ##Inserta el valor de la variable r (el resultado de la suma) en la posición 0 del Entry resultado. Esto coloca el resultado en el Entry.
    resultado.config(state="readonly")  ## cambia a atributo sololectura
 
# Botón sumar  
boton = tk.Button(root, text="Sumar", command=sumar)
boton.grid(row=3, column=0)

# Bucle principal
root.mainloop()