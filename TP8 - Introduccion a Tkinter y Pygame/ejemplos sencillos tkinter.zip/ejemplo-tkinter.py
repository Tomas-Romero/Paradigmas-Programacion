import tkinter as tk
from tkinter import messagebox

# Clase principal de la aplicación
class TaskManagerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Gestor de Tareas")
        
        # Lista de tareas
        self.tasks = []
        
        # Crear widgets
        self.create_widgets()
    
    def create_widgets(self):
        # Entrada de texto para nuevas tareas
        self.task_entry = tk.Entry(self.root, width=50)
        self.task_entry.pack(pady=10)
        
        # Botón para agregar tareas
        self.add_task_button = tk.Button(self.root, text="Agregar Tarea", command=self.add_task)
        self.add_task_button.pack(pady=5)
        
        # Lista de tareas
        self.task_listbox = tk.Listbox(self.root, width=50, height=10)
        self.task_listbox.pack(pady=10)
        
        # Botón para eliminar tareas
        self.delete_task_button = tk.Button(self.root, text="Eliminar Tarea", command=self.delete_task)
        self.delete_task_button.pack(pady=5)
        
        # Botón para marcar tareas como completadas
        self.complete_task_button = tk.Button(self.root, text="Marcar como Completada", command=self.complete_task)
        self.complete_task_button.pack(pady=5)
    
    def add_task(self):
        # Obtener el texto de la entrada
        task = self.task_entry.get()
        if task:
            # Agregar tarea a la lista y actualizar la Listbox
            self.tasks.append(task)
            self.update_task_listbox()
            self.task_entry.delete(0, tk.END)
        else:
            messagebox.showwarning("Advertencia", "No se puede agregar una tarea vacía.")
    
    def delete_task(self):
        try:
            # Obtener el índice de la tarea seleccionada y eliminarla
            selected_task_index = self.task_listbox.curselection()[0]
            del self.tasks[selected_task_index]
            self.update_task_listbox()
        except IndexError:
            messagebox.showwarning("Advertencia", "Por favor, selecciona una tarea para eliminar.")
    
    def complete_task(self):
        try:
            # Obtener el índice de la tarea seleccionada y marcarla como completada
            selected_task_index = self.task_listbox.curselection()[0]
            self.tasks[selected_task_index] += " (Completada)"
            self.update_task_listbox()
        except IndexError:
            messagebox.showwarning("Advertencia", "Por favor, selecciona una tarea para marcar como completada.")
    
    def update_task_listbox(self):
        # Limpiar la Listbox y agregar todas las tareas nuevamente
        self.task_listbox.delete(0, tk.END)
        for task in self.tasks:
            self.task_listbox.insert(tk.END, task)

# Crear la ventana principal de Tkinter
root = tk.Tk()
app = TaskManagerApp(root)
root.mainloop()
