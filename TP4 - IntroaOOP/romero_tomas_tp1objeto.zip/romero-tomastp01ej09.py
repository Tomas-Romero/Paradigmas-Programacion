#Estudiante: Tomas Agustin Romero | Paradigmas de la Programacion 2024

#Ejercicio 9
#Preguntas

# ¿Puedo tener mas de una clase en un archivo?
#Si, si se puede tener mas de 1 clase en un mismo archivo, la practica de lo mismo se encuentra en el ejercicio 8

#□ ¿Se pueden crear multiples objetos de una misma clase?
#Si, pueden haber multiples objetos simultaneamente

#□ ¿Clase e Instancia, son lo mismo?
#No son lo mismo, una instancia es un objeto de la clase, las instancias van a tener atributos y caracteristicas similares que surgen de un mismo tipo de clases.